-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2026 at 07:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agri_smart`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_sign`
--

CREATE TABLE `admin_sign` (
  `nic` int(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `address` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_sign`
--

INSERT INTO `admin_sign` (`nic`, `full_name`, `dob`, `phone_no`, `address`, `email`) VALUES
(1, 'nuwan', '1980-01-09', '0717171034', 'hambantota', 'nuwan@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `admin_up`
--

CREATE TABLE `admin_up` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_up`
--

INSERT INTO `admin_up` (`username`, `password`, `repassword`) VALUES
('', '', ''),
('nuwan', '123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `bank_name` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `account_no` varchar(100) NOT NULL,
  `account_name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`bank_name`, `branch`, `account_no`, `account_name`) VALUES
('HNB', 'ratnapura', '1234567890', 'nithashi');

-- --------------------------------------------------------

--
-- Table structure for table `crops`
--

CREATE TABLE `crops` (
  `price` varchar(50) NOT NULL,
  `quantity` int(50) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `validity` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `crops`
--

INSERT INTO `crops` (`price`, `quantity`, `item_name`, `validity`) VALUES
('120.00', 11, 'carrot ', 'Not Valid'),
('300.00', 9, 'leeks ', 'Not Valid'),
('200.00', 7, 'potato', 'Valid'),
('250.00', 12, 'cabbage', 'Valid'),
('320.00', 11, 'onion ', 'Not Valid'),
('150.00', 6, 'chilli', 'Valid'),
('400.00', 8, 'pumpkin ', 'Not Valid'),
('250.00', 9, 'beans', 'Valid'),
('130.00', 16, 'brinjal ', 'Not Valid'),
('430.00', 16, 'tomato', 'Valid'),
('124.00', 5, 'radish', 'Valid'),
('340.00', 10, 'beetroot ', 'Not Valid');

-- --------------------------------------------------------

--
-- Table structure for table `cus_sign`
--

CREATE TABLE `cus_sign` (
  `nic` int(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `address` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cus_sign`
--

INSERT INTO `cus_sign` (`nic`, `full_name`, `dob`, `phone_no`, `address`, `email`) VALUES
(1, 'sasini', '2005-05-24', '0712101239', 'matara', 'sasi@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `cus_up`
--

CREATE TABLE `cus_up` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cus_up`
--

INSERT INTO `cus_up` (`username`, `password`, `repassword`) VALUES
('sasini', '111', '111');

-- --------------------------------------------------------

--
-- Table structure for table `farmersign`
--

CREATE TABLE `farmersign` (
  `nic` int(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `phone_no` varchar(20) NOT NULL,
  `address` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmersign`
--

INSERT INTO `farmersign` (`nic`, `full_name`, `dob`, `phone_no`, `address`, `email`) VALUES
(1, 'nithashi', '2005-05-24', '0123456780', 'ratnapura', 'nith@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `user_pwd`
--

CREATE TABLE `user_pwd` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `repassword` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_pwd`
--

INSERT INTO `user_pwd` (`username`, `password`, `repassword`) VALUES
('nithashi', '12345', '12345');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_sign`
--
ALTER TABLE `admin_sign`
  ADD PRIMARY KEY (`nic`);

--
-- Indexes for table `cus_sign`
--
ALTER TABLE `cus_sign`
  ADD PRIMARY KEY (`nic`);

--
-- Indexes for table `farmersign`
--
ALTER TABLE `farmersign`
  ADD PRIMARY KEY (`nic`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_sign`
--
ALTER TABLE `admin_sign`
  MODIFY `nic` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cus_sign`
--
ALTER TABLE `cus_sign`
  MODIFY `nic` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `farmersign`
--
ALTER TABLE `farmersign`
  MODIFY `nic` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
