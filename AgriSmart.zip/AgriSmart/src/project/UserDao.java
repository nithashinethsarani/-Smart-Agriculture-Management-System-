/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;
import javax.swing.JOptionPane;
import user.user1;
import java.sql.*;
import user.customer;
import user.admin;



/**
 *
 * @author Nithashi
 */
public class UserDao {
    public static void save (user1 user){
        
        String query = "insert into farmersign(full_name, dob, phone_no, address, email) "
                     + "values('" + user.getName() + "', "
                     + "'" + user.getDateofbirth() + "', " 
                     + "'" + user.getPhoneno() + "', "
                     + "'" + user.getAddress() + "', "
                     + "'" + user.getEmail() + "')";
        
        dboperations.setDataOrDelete(query, "Registered Successfully!");
    }
    
    public static void saveLogin(user1 user) {
        String query = "insert into user_pwd(username, password, repassword) "
                 + "values('" + user.getusername() + "', "
                 + "'" + user.getpassword() + "', "
                 + "'" + user.getrepassword() + "')"; 

    dboperations.setDataOrDelete(query, "Successfully!");
}
    
    public static void saveBankDetails(user1 user) { 
    String query = "insert into bank (bank_name, branch, account_no, account_name) "
            + "values('" + user.getbank_name() + "', "
            + "'" + user.getbranch() + "', "
            + "'" + user.getaccount_no() + "', "
            + "'" + user.getaccount_name() + "')";
    
    dboperations.setDataOrDelete(query, "Signup Successfully!");
 }
    
    public static user1 login(String username, String password){
        user1 user = null;
        try{
            ResultSet rs = dboperations.getData("select * from user_pwd where username='" + username + "' and password='" + password + "'");
            if (rs != null && rs.next()) {
            {
                user= new user1();
                
            }
        }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            
        }
        return user;
    }
    
    
    
    public static void cus(customer user){
        
        String query = "insert into cus_sign(full_name, dob, phone_no, address, email) "
                     + "values('" + user.getfull_name() + "', "
                     + "'" + user.getdob() + "', " 
                     + "'" + user.getphone_no() + "', "
                     + "'" + user.getaddress() + "', "
                     + "'" + user.getemail() + "')";
        
        dboperations.setDataOrDelete(query, "Registered Successfully!");
    }
    
    public static void up(customer user) {
        String query = "insert into cus_up(username, password, repassword) "
                 + "values('" + user.getusername() + "', "
                 + "'" + user.getpassword() + "', "
                 + "'" + user.getrepassword() + "')"; 

    dboperations.setDataOrDelete(query, "Successfully!");
}
    
    
    
     public static customer log(String username, String password){
        customer user = null;
        try{
            ResultSet rs = dboperations.getData("select * from cus_up where username='" + username + "' and password='" + password + "'");
            if (rs != null && rs.next()) {
            {
                user= new customer();
                
            }
        }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            
        }
        return user;
    }
     
     public static void updateCrop(String name, String price, String quantity) {

    String query = "UPDATE crops SET price='" + price + "', quantity='" + quantity + "', validity='Pending' WHERE item_name='" + name + "'";
    dboperations.setDataOrDelete(query, ""); 
}
      
      
      public static ResultSet getAllCrops() {
   
    String query = "select * from crops";
    return dboperations.getData(query);
}
      
      
      
        public static void admin(admin user){
        
        String query = "insert into admin_sign(full_name, dob, phone_no, address, email) "
                     + "values('" + user.getName() + "', "
                     + "'" + user.getDateofbirth() + "', " 
                     + "'" + user.getPhoneno() + "', "
                     + "'" + user.getAddress() + "', "
                     + "'" + user.getEmail() + "')";
        
        dboperations.setDataOrDelete(query, "Registered Successfully!");
    }
    
        
    public static void admin1(admin user) {
        String query = "insert into admin_up(username, password, repassword) "
                 + "values('" + user.getusername() + "', "
                 + "'" + user.getpassword() + "', "
                 + "'" + user.getrepassword() + "')"; 

    dboperations.setDataOrDelete(query, "Successfully!");
}
    
    
    
    public static admin admin2(String username, String password){
        admin user = null;
        try{
            ResultSet rs = dboperations.getData("select * from admin_up where username='" + username + "' and password='" + password + "'");
            if (rs != null && rs.next()) {
            {
                user= new admin();
                
            }
        }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
            
        }
        return user;
    }
}
