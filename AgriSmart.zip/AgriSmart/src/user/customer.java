/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package user;

/**
 *
 * @author Nithashi
 */
public class customer {
    

    private String full_name;
    private String nic;
    private String dob;
    private String phone_no;
    private String address;
    private String email;
    private String username;
    private String password;
    private String repassword;
    

    
    public String getfull_name() {
        return full_name;
    }

    public void setfull_name(String full_name) {
        this.full_name = full_name;
    }

    
    public String getnic() {
        return nic;
    }

    public void setnic(String nic) {
        this.nic = nic;
    }

   
    public String getdob() {
        return dob;
    }

    public void setdob(String dob) {
        this.dob = dob;
    }

   
    public String getphone_no() {
        return phone_no;
    }

    public void setphone_no(String phone_no) {
        this.phone_no = phone_no;
    }

 
    public String getaddress() {
        return address;
    }

    public void setaddress(String address) {
        this.address = address;
    }

   
    public String getemail() {
        return email;
    }

    public void setemail(String email) {
        this.email = email;
    }
    
    
    
   
     public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }
    
     public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }
    
    
     public String getrepassword() {
        return repassword;
    }

    public void setrepassword(String repassword) {
        this.repassword = repassword;
    }
    
    
  

}

    
