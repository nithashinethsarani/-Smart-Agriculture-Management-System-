/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package user;

/**
 *
 * @author Nithashi
 */
public class admin {
    private String price;
    private String quantity;
    private String name;
    private String nic;
    private String dateofbirth;
    private String phoneno;
    private String address;
    private String email;
    private String username;
    private String password;
    private String repassword;
    

    // Getter and Setter for Name
    public String getprice() {
        return price;
    }

    public void setprice(String price) {
        this.price = price;
    }

    // Getter and Setter for NIC
    public String getquantity() {
        return quantity;
    }

    public void setquantity(String quantity) {
        this.quantity =quantity;
    }
    
      // Getter and Setter for Name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for NIC
    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    // Getter and Setter for Date of Birth
    public String getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    // Getter and Setter for Phone No
    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    // Getter and Setter for Address
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Getter and Setter for Email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
    
    // Getter and Setter for Email
     public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }
    // Getter and Setter for Email
     public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }
    
    // Getter and Setter for Email
     public String getrepassword() {
        return password;
    }

    public void setrepassword(String repassword) {
        this.repassword = repassword;
    }
}
