/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package user;

public class user1 {

    private String name;
    private String nic;
    private String dateofbirth;
    private String phoneno;
    private String address;
    private String email;
    private String username;
    private String password;
    private String repassword;
    private String bank_name;
    private String branch;
    private String account_no;
    private String account_name;

    // Getter and Setter for Name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter and Setter for NIC
    public String getNic() {
        return nic;
    }

    public void setNic(String nic) {
        this.nic = nic;
    }

    // Getter and Setter for Date of Birth
    public String getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }

    // Getter and Setter for Phone No
    public String getPhoneno() {
        return phoneno;
    }

    public void setPhoneno(String phoneno) {
        this.phoneno = phoneno;
    }

    // Getter and Setter for Address
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Getter and Setter for Email
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
    
    // Getter and Setter for Email
     public String getusername() {
        return username;
    }

    public void setusername(String username) {
        this.username = username;
    }
    // Getter and Setter for Email
     public String getpassword() {
        return password;
    }

    public void setpassword(String password) {
        this.password = password;
    }
    
    // Getter and Setter for Email
     public String getrepassword() {
        return password;
    }

    public void setrepassword(String repassword) {
        this.repassword = repassword;
    }
    
    
    
    
    
    
    // Getter and Setter for Email
    public String getbank_name() {
        return bank_name;
    }

    public void setbank_name(String bank_name) {
        this.bank_name = bank_name;
    }
    // Getter and Setter for Email
     public String getbranch() {
        return branch;
    }

    public void setbranch(String branch) {
        this.branch = branch;
    }
    // Getter and Setter for Email
     public String getaccount_no() {
        return account_no;
    }

    public void setaccount_no(String account_no) {
        this.account_no =account_no;
    }
    
    // Getter and Setter for Email
     public String getaccount_name() {
             return account_name;
    }

    public void setaccount_name(String account_name) {
        this.account_name = account_name;
    }

    

}


